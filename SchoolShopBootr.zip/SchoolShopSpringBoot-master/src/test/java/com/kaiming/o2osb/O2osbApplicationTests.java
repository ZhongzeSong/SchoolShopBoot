package com.kaiming.o2osb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class O2osbApplicationTests {

    @Test
    void contextLoads() {
    }

}
