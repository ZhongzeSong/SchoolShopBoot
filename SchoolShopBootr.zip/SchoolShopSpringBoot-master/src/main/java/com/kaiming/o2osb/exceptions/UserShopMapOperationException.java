package com.kaiming.o2osb.exceptions;

public class UserShopMapOperationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2309031889018396278L;

	public UserShopMapOperationException(String msg) {
		super(msg);
	}
}
