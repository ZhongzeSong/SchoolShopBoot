package com.kaiming.o2osb.exceptions;

public class ShopAuthMapOperationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7990469618932924844L;

	public ShopAuthMapOperationException(String msg) {
		super(msg);
	}
}
