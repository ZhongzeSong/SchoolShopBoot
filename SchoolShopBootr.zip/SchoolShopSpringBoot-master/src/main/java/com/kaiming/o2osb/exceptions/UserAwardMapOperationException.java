package com.kaiming.o2osb.exceptions;

public class UserAwardMapOperationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3022463597988213145L;

	public UserAwardMapOperationException(String msg) {
		super(msg);
	}
}
