package com.kaiming.o2osb.exceptions;

public class AwardOperationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6160145499284104244L;

	public AwardOperationException(String msg) {
		super(msg);
	}
}
