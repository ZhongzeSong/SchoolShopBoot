package com.kaiming.o2osb.dto;

public class ConstantForSuperAdmin {
	public static final String PAGE_SIZE = "rows";
	public static final String PAGE_NO = "page";
	public static final String TOTAL = "total";
}
