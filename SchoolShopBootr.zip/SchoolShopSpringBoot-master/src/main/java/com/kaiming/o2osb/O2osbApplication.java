package com.kaiming.o2osb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class O2osbApplication {

    public static void main(String[] args) {
        SpringApplication.run(O2osbApplication.class, args);
    }

}
