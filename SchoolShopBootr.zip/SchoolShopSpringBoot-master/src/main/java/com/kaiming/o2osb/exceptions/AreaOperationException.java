package com.kaiming.o2osb.exceptions;

public class AreaOperationException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1512771573934050550L;

	public AreaOperationException(String msg) {
		super(msg);
	}
}
